package db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/todo_db?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USER = "root";  // your username
    private static final String PASS = "Shivanshi@2602"; // your password

    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            e.printStackTrace();   // VERY IMPORTANT → so we can see the real error
        }
        return con;
    }
}
